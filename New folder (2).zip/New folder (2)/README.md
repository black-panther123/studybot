# Study Bot Application

An AI-powered learning assistant with admin & student views, supporting text summarization, flashcards, OCR, and chatbot features.

## 🚀 Tech Stack

- **Frontend**: Next.js (App Router), Tailwind CSS
- **Backend**: Django (REST API), Django REST Framework
- **Database**: PostgreSQL (via Supabase)
- **Authentication**: Supabase Auth
- **AI Models**:
  - T5 for text summarization
  - Wave2Vec2 for speech-to-text
  - MarianMT for multilingual support
  - Google Vision for OCR
  - RoBERTa for real-time question answering

## 📋 Requirements

- Python 3.8+
- Node.js v18+
- npm v9+
- Supabase account
- (Optional) Google Cloud account for OCR

## 🔧 How to Run the Application

### Easy Setup (Windows)

1. Simply run the `start.bat` script:

```
start.bat
```

This will automatically:
- Create and activate a virtual environment
- Install backend dependencies
- Run Django migrations
- Start the Django server
- Install frontend dependencies
- Start the Next.js development server

### Manual Setup

#### Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```

2. Create and activate a virtual environment:
   ```bash
   # Windows
   python -m venv venv
   venv\Scripts\activate

   # macOS/Linux
   python -m venv venv
   source venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Create a `.env` file in the backend directory:
   ```
   SECRET_KEY=django-insecure-random-secret-key-for-development
   DEBUG=True
   DATABASE_URL=sqlite:///db.sqlite3
   SUPABASE_URL=https://zprjxdxttilglvlqpoct.supabase.co
   SUPABASE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpwcmp4ZHh0dGlsZ2x2bHFwb2N0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIwMjM0MzksImV4cCI6MjA1NzU5OTQzOX0.6WQz7mTUblp1hl-IHIkxJ3cLea9xRP4DnhhbPt4rogk
   ALLOWED_HOSTS=localhost,127.0.0.1
   CORS_ALLOWED_ORIGINS=http://localhost:3000
   ```

5. Run migrations:
   ```bash
   python manage.py migrate
   ```

6. Create a superuser (optional):
   ```bash
   python manage.py createsuperuser
   ```

7. Start the Django server:
   ```bash
   python manage.py runserver
   ```

#### Frontend Setup

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env.local` file in the frontend directory:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://zprjxdxttilglvlqpoct.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inpwcmp4ZHh0dGlsZ2x2bHFwb2N0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDIwMjM0MzksImV4cCI6MjA1NzU5OTQzOX0.6WQz7mTUblp1hl-IHIkxJ3cLea9xRP4DnhhbPt4rogk
   NEXT_PUBLIC_API_URL=http://localhost:8000/api
   ```

4. Start the Next.js development server:
   ```bash
   npm run dev
   ```

### Supabase Setup

1. Copy the SQL commands from `supabase_setup.sql`
2. Go to your Supabase project dashboard
3. Navigate to the SQL Editor
4. Paste and run the SQL commands to set up tables, RLS policies, and triggers

## 🌐 Accessing the Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:8000/api
- **Django Admin**: http://localhost:8000/admin (login with superuser credentials)

## 🔧 Troubleshooting Common Issues

### Backend Issues

1. **Missing Dependencies**
   - Error: `ModuleNotFoundError: No module named 'x'`
   - Solution: Install the missing package with `pip install x`

2. **Environment Variables Not Loaded**
   - Error: Missing or invalid configuration values
   - Solution: Check that the `.env` file exists and has correct values

3. **Database Migration Issues**
   - Error: `Django migrations are pending`
   - Solution: Run `python manage.py migrate`

### Frontend Issues

1. **Node Modules Issues**
   - Error: `Module not found`
   - Solution: Delete `node_modules` and run `npm install` again

2. **API Connection Issues**
   - Error: Cannot connect to backend API
   - Solution: Ensure the backend is running and CORS is properly configured

3. **Supabase Connection Issues**
   - Error: Cannot connect to Supabase
   - Solution: Verify Supabase URL and key in `.env.local`

## 📚 Features

- **Text Summarization**: Upload and summarize text documents
- **Flashcards**: Create and study flashcards
- **OCR**: Extract text from images
- **Chatbot**: Ask questions about your documents
- **Admin Dashboard**: Manage users and content
- **Student Dashboard**: Access learning tools

## 🔐 Authentication

The application uses Supabase for authentication:
- Email/Password signup and login
- Role-based access control (admin/student)
- Secure token handling

## 📜 License

MIT License 