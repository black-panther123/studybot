-- UserProfile Table
CREATE TABLE IF NOT EXISTS user_profiles (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  role VARCHAR(10) NOT NULL DEFAULT 'student' CHECK (role IN ('admin', 'student')),
  profile_picture VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Document Table
CREATE TABLE IF NOT EXISTS documents (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  file_url VARCHAR(255),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Summary Table
CREATE TABLE IF NOT EXISTS summaries (
  id BIGSERIAL PRIMARY KEY,
  document_id BIGINT REFERENCES documents NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Flashcard Table
CREATE TABLE IF NOT EXISTS flashcards (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  document_id BIGINT REFERENCES documents,
  question TEXT NOT NULL,
  answer TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- FlashcardDeck Table
CREATE TABLE IF NOT EXISTS flashcard_decks (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- FlashcardDeck-Flashcard Many-to-Many Relationship
CREATE TABLE IF NOT EXISTS flashcard_deck_items (
  id BIGSERIAL PRIMARY KEY,
  deck_id BIGINT REFERENCES flashcard_decks NOT NULL,
  flashcard_id BIGINT REFERENCES flashcards NOT NULL,
  UNIQUE(deck_id, flashcard_id)
);

-- OCRDocument Table
CREATE TABLE IF NOT EXISTS ocr_documents (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  image_url VARCHAR(255) NOT NULL,
  extracted_text TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ChatSession Table
CREATE TABLE IF NOT EXISTS chat_sessions (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  title VARCHAR(255) NOT NULL DEFAULT 'New Chat',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ChatMessage Table
CREATE TABLE IF NOT EXISTS chat_messages (
  id BIGSERIAL PRIMARY KEY,
  session_id BIGINT REFERENCES chat_sessions NOT NULL,
  message_type VARCHAR(10) NOT NULL CHECK (message_type IN ('user', 'bot')),
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- UserSettings Table
CREATE TABLE IF NOT EXISTS user_settings (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL UNIQUE,
  theme VARCHAR(10) NOT NULL DEFAULT 'system' CHECK (theme IN ('light', 'dark', 'system')),
  notification_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE summaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE flashcards ENABLE ROW LEVEL SECURITY;
ALTER TABLE flashcard_decks ENABLE ROW LEVEL SECURITY;
ALTER TABLE flashcard_deck_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE ocr_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- User Profiles: Users can read and update their own profiles, admins can read all
CREATE POLICY "Users can view own profile" ON user_profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON user_profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Admin can view all profiles" ON user_profiles FOR SELECT USING (
  EXISTS (SELECT 1 FROM user_profiles WHERE user_id = auth.uid() AND role = 'admin')
);

-- Documents: Users can CRUD their own documents
CREATE POLICY "Users can CRUD own documents" ON documents FOR ALL USING (auth.uid() = user_id);

-- Summaries: Users can read summaries of their documents
CREATE POLICY "Users can read summaries of own documents" ON summaries FOR SELECT USING (
  EXISTS (SELECT 1 FROM documents WHERE documents.id = summaries.document_id AND documents.user_id = auth.uid())
);

-- Flashcards: Users can CRUD their own flashcards
CREATE POLICY "Users can CRUD own flashcards" ON flashcards FOR ALL USING (auth.uid() = user_id);

-- Flashcard Decks: Users can CRUD their own decks
CREATE POLICY "Users can CRUD own flashcard decks" ON flashcard_decks FOR ALL USING (auth.uid() = user_id);

-- Flashcard Deck Items: Users can access items in their own decks
CREATE POLICY "Users can access own deck items" ON flashcard_deck_items FOR ALL USING (
  EXISTS (SELECT 1 FROM flashcard_decks WHERE flashcard_decks.id = flashcard_deck_items.deck_id AND flashcard_decks.user_id = auth.uid())
);

-- OCR Documents: Users can CRUD their own OCR documents
CREATE POLICY "Users can CRUD own OCR documents" ON ocr_documents FOR ALL USING (auth.uid() = user_id);

-- Chat Sessions: Users can CRUD their own chat sessions
CREATE POLICY "Users can CRUD own chat sessions" ON chat_sessions FOR ALL USING (auth.uid() = user_id);

-- Chat Messages: Users can access messages from their own sessions
CREATE POLICY "Users can access messages from own sessions" ON chat_messages FOR ALL USING (
  EXISTS (SELECT 1 FROM chat_sessions WHERE chat_sessions.id = chat_messages.session_id AND chat_sessions.user_id = auth.uid())
);

-- User Settings: Users can read and update their own settings
CREATE POLICY "Users can read own settings" ON user_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update own settings" ON user_settings FOR UPDATE USING (auth.uid() = user_id);

-- Function to update timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply to tables with updated_at
CREATE TRIGGER update_user_profiles_timestamp
BEFORE UPDATE ON user_profiles
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();

CREATE TRIGGER update_documents_timestamp
BEFORE UPDATE ON documents
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();

CREATE TRIGGER update_flashcard_decks_timestamp
BEFORE UPDATE ON flashcard_decks
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();

CREATE TRIGGER update_user_settings_timestamp
BEFORE UPDATE ON user_settings
FOR EACH ROW EXECUTE PROCEDURE update_timestamp();

-- Add indexes
CREATE INDEX idx_documents_user_id ON documents(user_id);
CREATE INDEX idx_flashcards_user_id ON flashcards(user_id);
CREATE INDEX idx_chat_sessions_user_id ON chat_sessions(user_id);
CREATE INDEX idx_chat_messages_session_id ON chat_messages(session_id);

-- Create a trigger to automatically create a user profile after signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (user_id, role)
  VALUES (NEW.id, 'student');
  
  INSERT INTO public.user_settings (user_id)
  VALUES (NEW.id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

# Hugging Face Configuration
HUGGINGFACE_API_TOKEN=your_huggingface_token_here

# Model IDs
T5_MODEL_ID=t5-small
WAVE2VEC2_MODEL_ID=facebook/wav2vec2-base-960h
MARIAN_MT_MODEL_ID=Helsinki-NLP/opus-mt-en-fr  # Example for English to French
ROBERTA_MODEL_ID=deepset/roberta-base-squad2 