import Link from 'next/link';
import Image from 'next/image';

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <header className="relative py-6 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold text-blue-600">Study Bot</h1>
        </div>
        <div className="flex items-center space-x-4">
          <Link 
            href="/login" 
            className="text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
          >
            Log in
          </Link>
          <Link 
            href="/register" 
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
          >
            Sign up
          </Link>
        </div>
      </header>

      <main>
        <section className="px-4 pt-16 pb-20 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between">
          <div className="max-w-xl mb-10 md:mb-0">
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              Transform Learning with AI-Powered Study Assistant
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">
              Study Bot helps you learn faster with AI-powered summarization, flashcards, 
              OCR text extraction, and a smart chatbot to answer your questions.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link 
                href="/register" 
                className="btn-primary text-center"
              >
                Get Started Free
              </Link>
              <Link 
                href="#features" 
                className="btn-secondary text-center"
              >
                Learn More
              </Link>
            </div>
          </div>
          <div className="w-full max-w-md glass-card p-8 rounded-3xl">
            <div className="w-full h-64 bg-blue-100 dark:bg-blue-900 rounded-2xl flex items-center justify-center">
              <p className="text-blue-600 dark:text-blue-300 text-center font-medium">
                AI Study Assistant Illustration
              </p>
            </div>
          </div>
        </section>

        <section id="features" className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-900">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
              Features That Make Learning Effortless
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  title: "Text Summarization",
                  description: "Convert long texts into concise summaries to help you focus on key concepts."
                },
                {
                  title: "Flashcard Generation",
                  description: "Automatically create flashcards from your study materials for effective revision."
                },
                {
                  title: "OCR Text Extraction",
                  description: "Extract text from images and scanned documents to digitize your notes."
                },
                {
                  title: "AI Chatbot",
                  description: "Get instant answers to your questions with our intelligent chatbot assistant."
                }
              ].map((feature, i) => (
                <div key={i} className="card bg-white dark:bg-gray-800 p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
                  <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg mb-4 flex items-center justify-center">
                    <span className="text-blue-600 dark:text-blue-400 font-bold">{i + 1}</span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">{feature.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Ready to Transform Your Learning?
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              Join thousands of students who are already using Study Bot to boost their learning efficiency
              and achieve better results.
            </p>
            <Link 
              href="/register" 
              className="btn-primary px-8 py-3 text-lg inline-block"
            >
              Start for Free
            </Link>
          </div>
        </section>
      </main>

      <footer className="bg-gray-100 dark:bg-gray-800 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <h2 className="text-xl font-bold text-blue-600">Study Bot</h2>
            <p className="text-gray-600 dark:text-gray-300 text-sm">© 2025 Study Bot. All rights reserved.</p>
          </div>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400">
              Terms
            </a>
            <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400">
              Privacy
            </a>
            <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400">
              Contact
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
} 