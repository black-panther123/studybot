'use client';

import { useState } from 'react';

export default function Flashcards() {
  const [text, setText] = useState('');
  const [title, setTitle] = useState('');
  const [flashcards, setFlashcards] = useState<{ question: string; answer: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeCard, setActiveCard] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [showForm, setShowForm] = useState(true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!text.trim()) {
      setError('Please enter some text to generate flashcards');
      return;
    }

    if (!title.trim()) {
      setError('Please enter a title for your flashcard deck');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // In a real implementation, we would call the Django API
      // For demo purposes, we'll create mock flashcards
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API call
      
      const generatedFlashcards = [
        {
          question: "What is the main topic of the text?",
          answer: "The main topic is about the fundamental concepts discussed in the content."
        },
        {
          question: "What are the key components mentioned?",
          answer: "The key components include theoretical frameworks, practical applications, and analytical methods."
        },
        {
          question: "When was the concept first introduced?",
          answer: "The concept was first introduced in the early stages of development, as mentioned in the text."
        },
        {
          question: "How do the various elements interact?",
          answer: "The elements interact through a complex system of relationships that build upon each other."
        },
        {
          question: "What are the implications of these findings?",
          answer: "The implications suggest significant advancements in understanding and applying these concepts in real-world scenarios."
        }
      ];
      
      setFlashcards(generatedFlashcards);
      setShowForm(false);
    } catch (err) {
      setError('Failed to generate flashcards. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleNextCard = () => {
    setFlipped(false);
    setActiveCard((prev) => (prev + 1) % flashcards.length);
  };

  const handlePrevCard = () => {
    setFlipped(false);
    setActiveCard((prev) => (prev - 1 + flashcards.length) % flashcards.length);
  };

  const toggleFlip = () => {
    setFlipped(!flipped);
  };

  const handleNewDeck = () => {
    setText('');
    setTitle('');
    setFlashcards([]);
    setActiveCard(0);
    setFlipped(false);
    setShowForm(true);
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Flashcards
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Generate study flashcards from your notes or create them manually.
        </p>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-sm">
          {error}
        </div>
      )}

      {showForm ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Deck Title
                </label>
                <input
                  id="title"
                  type="text"
                  className="input-field"
                  placeholder="Enter a title for your flashcard deck"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="text" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Study Text
                </label>
                <textarea
                  id="text"
                  rows={10}
                  className="input-field font-mono text-sm"
                  placeholder="Paste your study notes or content here to generate flashcards"
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  required
                />
              </div>
              <button
                type="submit"
                className="btn-primary w-full py-2.5"
                disabled={loading}
              >
                {loading ? (
                  <span className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Generating Flashcards...
                  </span>
                ) : "Generate Flashcards"}
              </button>
            </form>

            <div className="mt-6">
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                Options
              </h3>
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 space-y-4">
                <div>
                  <label htmlFor="cardCount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Number of Cards
                  </label>
                  <select
                    id="cardCount"
                    className="input-field"
                    defaultValue="5"
                  >
                    <option value="5">5 cards</option>
                    <option value="10">10 cards</option>
                    <option value="15">15 cards</option>
                    <option value="20">20 cards</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="difficulty" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Difficulty
                  </label>
                  <select
                    id="difficulty"
                    className="input-field"
                    defaultValue="medium"
                  >
                    <option value="basic">Basic</option>
                    <option value="medium">Medium</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Your Flashcard Decks
            </h3>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5 min-h-[400px]">
              <div className="flex flex-col h-full justify-center items-center text-center">
                {loading ? (
                  <p className="text-gray-500 dark:text-gray-400">Generating flashcards...</p>
                ) : (
                  <>
                    <div className="w-24 h-24 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mb-4">
                      <span className="text-blue-600 dark:text-blue-300 text-4xl">🗂️</span>
                    </div>
                    <h4 className="text-xl font-medium text-gray-900 dark:text-white mb-2">
                      No Flashcards Yet
                    </h4>
                    <p className="text-gray-500 dark:text-gray-400 mb-4">
                      Generate your first deck of flashcards by entering your study material.
                    </p>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center">
          <div className="w-full max-w-2xl mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{title}</h2>
              <div className="flex space-x-2">
                <button 
                  onClick={handleNewDeck}
                  className="btn-secondary text-sm py-1.5 px-3"
                >
                  New Deck
                </button>
                <button className="btn-secondary text-sm py-1.5 px-3">
                  Edit Deck
                </button>
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-4 h-80 cursor-pointer"
                 onClick={toggleFlip}>
              <div className="h-full flex flex-col justify-center items-center">
                {flipped ? (
                  <div className="animate-fade-in">
                    <h3 className="text-lg font-semibold text-gray-500 dark:text-gray-400 mb-2">Answer:</h3>
                    <p className="text-xl text-center text-gray-900 dark:text-white">
                      {flashcards[activeCard]?.answer}
                    </p>
                  </div>
                ) : (
                  <div className="animate-fade-in">
                    <h3 className="text-lg font-semibold text-gray-500 dark:text-gray-400 mb-2">Question:</h3>
                    <p className="text-xl text-center text-gray-900 dark:text-white">
                      {flashcards[activeCard]?.question}
                    </p>
                  </div>
                )}
                <p className="mt-8 text-sm text-gray-500">Click to flip</p>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <button 
                onClick={handlePrevCard}
                className="btn-secondary py-2 px-4 flex items-center"
              >
                <span className="mr-1">←</span> Previous
              </button>
              <div className="text-gray-600 dark:text-gray-300">
                {activeCard + 1} / {flashcards.length}
              </div>
              <button 
                onClick={handleNextCard}
                className="btn-secondary py-2 px-4 flex items-center"
              >
                Next <span className="ml-1">→</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 