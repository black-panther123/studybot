from django.shortcuts import render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from rest_framework import status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework.authtoken.models import Token

from .models import (
    UserProfile, Document, Summary, Flashcard, 
    FlashcardDeck, OCRDocument, ChatSession, ChatMessage,
    UserSettings
)
from .serializers import (
    UserSerializer, UserProfileSerializer, DocumentSerializer,
    SummarySerializer, FlashcardSerializer, FlashcardDeckSerializer,
    OCRDocumentSerializer, ChatSessionSerializer, ChatMessageSerializer,
    UserSettingsSerializer, RegistrationSerializer
)
from .ai_services import TextSummarizer, OCRService, SpeechToTextService

# Authentication Views
@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def register_view(request):
    serializer = RegistrationSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.save()
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user': UserSerializer(user).data,
            'role': user.profile.role
        }, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login_view(request):
    username = request.data.get('username')
    password = request.data.get('password')
    
    user = authenticate(username=username, password=password)
    if user:
        login(request, user)
        token, created = Token.objects.get_or_create(user=user)
        return Response({
            'token': token.key,
            'user': UserSerializer(user).data,
            'role': user.profile.role
        })
    return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def logout_view(request):
    logout(request)
    return Response({'success': 'Logged out successfully'})

# AI Feature Views
@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def summarize_text(request):
    """
    Summarize a text passage or document.
    """
    text = request.data.get('text')
    document_id = request.data.get('document_id')
    max_length = int(request.data.get('max_length', 150))
    min_length = int(request.data.get('min_length', 30))
    
    if not text and not document_id:
        return Response(
            {'error': 'Either text or document_id must be provided'}, 
            status=status.HTTP_400_BAD_REQUEST
        )
    
    # If document_id is provided, get text from document
    if document_id:
        try:
            document = Document.objects.get(id=document_id, user=request.user)
            text = document.content
        except Document.DoesNotExist:
            return Response(
                {'error': 'Document not found'}, 
                status=status.HTTP_404_NOT_FOUND
            )
    
    # Use our text summarizer service
    summarizer = TextSummarizer()
    summary_text = summarizer.summarize(text, max_length=max_length, min_length=min_length)
    
    # Save summary if it's from a document
    if document_id:
        summary = Summary.objects.create(
            document_id=document_id,
            content=summary_text
        )
        return Response(SummarySerializer(summary).data)
    
    # Return just the summary text if no document_id
    return Response({'summary': summary_text})

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def generate_flashcards(request):
    text = request.data.get('text')
    if not text:
        return Response({'error': 'No text provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    # In production, we'd use an NLP model to generate Q&A pairs
    # For this demo, we'll just return a mock flashcard
    flashcards = [
        {"question": "What is the main topic of the text?", "answer": "The main topic is about the content."},
        {"question": "What are the key points mentioned?", "answer": "Several key points are mentioned."}
    ]
    
    # Create document and flashcards
    document = Document.objects.create(
        user=request.user,
        title="Flashcard Document " + str(Document.objects.count() + 1),
        content=text
    )
    
    saved_flashcards = []
    for card in flashcards:
        flashcard = Flashcard.objects.create(
            user=request.user,
            document=document,
            question=card['question'],
            answer=card['answer']
        )
        saved_flashcards.append(FlashcardSerializer(flashcard).data)
    
    return Response({
        'flashcards': saved_flashcards,
        'document_id': document.id
    })

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def process_ocr(request):
    """
    Extract text from an image using OCR.
    """
    image_file = request.FILES.get('image')
    if not image_file:
        return Response({'error': 'No image provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    # Save the image
    ocr_document = OCRDocument.objects.create(
        user=request.user,
        image_url=image_file.name
    )
    
    # Save the file to a temporary location
    import os
    from django.conf import settings
    
    if not os.path.exists(settings.MEDIA_ROOT):
        os.makedirs(settings.MEDIA_ROOT)
    
    file_path = os.path.join(settings.MEDIA_ROOT, image_file.name)
    with open(file_path, 'wb+') as destination:
        for chunk in image_file.chunks():
            destination.write(chunk)
    
    # Use OCR service to extract text
    ocr_service = OCRService()
    try:
        extracted_text = ocr_service.extract_text(file_path)
        
        # Update the OCR document with the extracted text
        ocr_document.extracted_text = extracted_text
        ocr_document.save()
        
        return Response({
            'id': ocr_document.id,
            'extracted_text': extracted_text,
            'image_url': ocr_document.image_url
        })
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def speech_to_text(request):
    """
    Convert speech audio to text.
    """
    audio_file = request.FILES.get('audio')
    if not audio_file:
        return Response({'error': 'No audio file provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    # Save the audio file to a temporary location
    import os
    from django.conf import settings
    
    if not os.path.exists(settings.MEDIA_ROOT):
        os.makedirs(settings.MEDIA_ROOT)
    
    file_path = os.path.join(settings.MEDIA_ROOT, audio_file.name)
    with open(file_path, 'wb+') as destination:
        for chunk in audio_file.chunks():
            destination.write(chunk)
    
    # Use speech-to-text service to transcribe
    stt_service = SpeechToTextService()
    try:
        transcribed_text = stt_service.transcribe(file_path)
        
        # Return the transcribed text
        return Response({
            'text': transcribed_text
        })
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def translate_text(request):
    text = request.data.get('text')
    target_language = request.data.get('target_language', 'fr')  # Default to French
    
    if not text:
        return Response({'error': 'No text provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    # In production, we'd use MarianMT for translation
    # For this demo, we'll just return a mock translation
    translation = f"This is a {target_language} translation of: {text[:50]}..."
    
    return Response({
        'translation': translation,
        'source_language': 'en',
        'target_language': target_language
    })

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def chatbot_response(request):
    message = request.data.get('message')
    session_id = request.data.get('session_id')
    
    if not message:
        return Response({'error': 'No message provided'}, status=status.HTTP_400_BAD_REQUEST)
    
    # Get or create chat session
    if session_id:
        try:
            session = ChatSession.objects.get(id=session_id, user=request.user)
        except ChatSession.DoesNotExist:
            return Response({'error': 'Chat session not found'}, status=status.HTTP_404_NOT_FOUND)
    else:
        session = ChatSession.objects.create(
            user=request.user,
            title="Chat " + str(ChatSession.objects.filter(user=request.user).count() + 1)
        )
    
    # Save user message
    user_message = ChatMessage.objects.create(
        session=session,
        message_type='user',
        content=message
    )
    
    # In production, we'd use RoBERTa for generating responses
    # For this demo, we'll just return a mock response
    bot_response = f"This is a response to: {message}"
    
    # Save bot message
    bot_message = ChatMessage.objects.create(
        session=session,
        message_type='bot',
        content=bot_response
    )
    
    return Response({
        'response': bot_response,
        'session_id': session.id,
        'user_message_id': user_message.id,
        'bot_message_id': bot_message.id
    })

# User Profile and Settings Views
@api_view(['GET', 'PUT'])
@permission_classes([permissions.IsAuthenticated])
def user_profile(request):
    try:
        profile = UserProfile.objects.get(user=request.user)
    except UserProfile.DoesNotExist:
        profile = UserProfile.objects.create(user=request.user)
    
    if request.method == 'GET':
        serializer = UserProfileSerializer(profile)
        return Response(serializer.data)
    
    if request.method == 'PUT':
        serializer = UserProfileSerializer(profile, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET', 'PUT'])
@permission_classes([permissions.IsAuthenticated])
def user_settings(request):
    try:
        settings = UserSettings.objects.get(user=request.user)
    except UserSettings.DoesNotExist:
        settings = UserSettings.objects.create(user=request.user)
    
    if request.method == 'GET':
        serializer = UserSettingsSerializer(settings)
        return Response(serializer.data)
    
    if request.method == 'PUT':
        serializer = UserSettingsSerializer(settings, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST) 