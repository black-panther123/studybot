from rest_framework import serializers
from django.contrib.auth.models import User
from .models import (
    UserProfile, Document, Summary, Flashcard, 
    FlashcardDeck, OCRDocument, ChatSession, ChatMessage,
    UserSettings
)

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']
        read_only_fields = ['id']

class UserProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = UserProfile
        fields = ['id', 'user', 'role', 'profile_picture', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

class DocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Document
        fields = ['id', 'user', 'title', 'content', 'file', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

class SummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Summary
        fields = ['id', 'document', 'content', 'created_at']
        read_only_fields = ['id', 'created_at']

class FlashcardSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flashcard
        fields = ['id', 'user', 'document', 'question', 'answer', 'created_at']
        read_only_fields = ['id', 'created_at']

class FlashcardDeckSerializer(serializers.ModelSerializer):
    flashcards = FlashcardSerializer(many=True, read_only=True)
    
    class Meta:
        model = FlashcardDeck
        fields = ['id', 'user', 'title', 'description', 'flashcards', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

class OCRDocumentSerializer(serializers.ModelSerializer):
    class Meta:
        model = OCRDocument
        fields = ['id', 'user', 'image', 'extracted_text', 'created_at']
        read_only_fields = ['id', 'created_at']

class ChatMessageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChatMessage
        fields = ['id', 'session', 'message_type', 'content', 'created_at']
        read_only_fields = ['id', 'created_at']

class ChatSessionSerializer(serializers.ModelSerializer):
    messages = ChatMessageSerializer(many=True, read_only=True)
    
    class Meta:
        model = ChatSession
        fields = ['id', 'user', 'title', 'messages', 'created_at']
        read_only_fields = ['id', 'created_at']

class UserSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserSettings
        fields = ['id', 'user', 'theme', 'notification_enabled', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']

class RegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    role = serializers.ChoiceField(choices=UserProfile.USER_ROLES, default='student')
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'first_name', 'last_name', 'role']
    
    def create(self, validated_data):
        role = validated_data.pop('role')
        user = User.objects.create_user(**validated_data)
        UserProfile.objects.create(user=user, role=role)
        UserSettings.objects.create(user=user)
        return user 