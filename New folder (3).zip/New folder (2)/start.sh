#!/bin/bash

echo "Starting the Study Bot Application..."

echo ""
echo "======================================"
echo "Step 1: Creating and activating virtual environment"
echo "======================================"
echo ""

if [ ! -d "backend/venv" ]; then
    echo "Creating virtual environment..."
    cd backend
    python3 -m venv venv
    cd ..
else
    echo "Virtual environment already exists."
fi

echo "Activating virtual environment..."
source backend/venv/bin/activate

echo ""
echo "======================================"
echo "Step 2: Installing backend dependencies"
echo "======================================"
echo ""

echo "Installing Python packages..."
cd backend
pip install -r requirements.txt

echo ""
echo "======================================"
echo "Step 3: Running Django migrations"
echo "======================================"
echo ""

echo "Running migrations..."
python manage.py migrate

echo ""
echo "======================================"
echo "Step 4: Starting Django server"
echo "======================================"
echo ""

echo "Starting Django server in the background..."
python manage.py runserver &
DJANGO_PID=$!

echo ""
echo "======================================"
echo "Step 5: Installing frontend dependencies"
echo "======================================"
echo ""

cd ..
cd frontend
echo "Installing Node.js packages..."
npm install

echo ""
echo "======================================"
echo "Step 6: Starting Next.js server"
echo "======================================"
echo ""

echo "Starting Next.js server..."
npm run dev &
NEXTJS_PID=$!

echo ""
echo "======================================"
echo "Study Bot Application Started!"
echo "======================================"
echo ""
echo "Backend running at: http://localhost:8000/"
echo "Frontend running at: http://localhost:3000/"
echo ""
echo "Press Ctrl+C to stop the application."
echo ""

# Handle graceful shutdown
trap 'kill $DJANGO_PID $NEXTJS_PID; echo ""; echo "Stopping all services..."; echo ""; exit 0' INT

# Keep the script running
wait 