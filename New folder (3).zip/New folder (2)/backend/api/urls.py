from django.urls import path
from . import views

urlpatterns = [
    # Authentication endpoints
    path('auth/login/', views.login_view, name='login'),
    path('auth/logout/', views.logout_view, name='logout'),
    path('auth/register/', views.register_view, name='register'),
    
    # AI feature endpoints
    path('summarize/', views.summarize_text, name='summarize'),
    path('flashcards/', views.generate_flashcards, name='flashcards'),
    path('ocr/', views.process_ocr, name='ocr'),
    path('speech-to-text/', views.speech_to_text, name='speech_to_text'),
    path('translate/', views.translate_text, name='translate'),
    path('chatbot/', views.chatbot_response, name='chatbot'),
    
    # User profile and settings
    path('user/profile/', views.user_profile, name='user_profile'),
    path('user/settings/', views.user_settings, name='user_settings'),
] 