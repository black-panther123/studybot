"""
AI Services for Study Bot

This module provides implementations for various AI capabilities:
- Text summarization (using BART or T5)
- Question answering (using Mistral 7B or DeepSeek)
- OCR (using EasyOCR)
- Speech to text (using Whisper or Wav2Vec2)
- Text to speech (using Coqui TTS)
- Translation (using M2M-100)
"""

import os
import logging
import requests
from django.conf import settings
from transformers import (
    AutoModelForSeq2SeqLM,
    AutoTokenizer,
    pipeline,
)

logger = logging.getLogger(__name__)

def get_huggingface_api_headers():
    """Get headers for Hugging Face API requests."""
    api_token = settings.HUGGINGFACE_API_TOKEN
    if not api_token:
        logger.warning("No Hugging Face API token provided")
    return {"Authorization": f"Bearer {api_token}"}

class TextSummarizer:
    """Text summarization service using BART or T5 models."""
    
    def __init__(self):
        self.model_config = settings.AI_MODELS['text_summarization']
        self.model_id = self.model_config['model_id']
        self.use_local = self.model_config['use_local']
        self.model = None
        self.tokenizer = None
        
    def _load_local_model(self):
        """Load the model locally."""
        if self.model is None:
            logger.info(f"Loading local summarization model: {self.model_id}")
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_id)
            self.model = AutoModelForSeq2SeqLM.from_pretrained(self.model_id)
            
    def _summarize_api(self, text, max_length=150, min_length=30):
        """Use Hugging Face API for summarization."""
        API_URL = f"https://api-inference.huggingface.co/models/{self.model_id}"
        headers = get_huggingface_api_headers()
        
        payload = {
            "inputs": text,
            "parameters": {
                "max_length": max_length,
                "min_length": min_length,
                "do_sample": False
            }
        }
        
        response = requests.post(API_URL, headers=headers, json=payload)
        response.raise_for_status()
        return response.json()[0]['summary_text']
    
    def _summarize_local(self, text, max_length=150, min_length=30):
        """Use local model for summarization."""
        self._load_local_model()
        
        summarizer = pipeline(
            "summarization", 
            model=self.model, 
            tokenizer=self.tokenizer
        )
        
        # Handle long texts by chunking if needed
        if len(text.split()) > 1000:
            # Implementation for chunking would go here
            # This is a simplified version
            chunks = [text[i:i+1000] for i in range(0, len(text), 1000)]
            summaries = []
            
            for chunk in chunks:
                result = summarizer(
                    chunk, 
                    max_length=max_length // len(chunks), 
                    min_length=min_length // len(chunks),
                    do_sample=False
                )
                summaries.append(result[0]['summary_text'])
            
            return " ".join(summaries)
        else:
            result = summarizer(
                text, 
                max_length=max_length, 
                min_length=min_length,
                do_sample=False
            )
            return result[0]['summary_text']
    
    def summarize(self, text, max_length=150, min_length=30):
        """Summarize the given text."""
        try:
            if self.use_local:
                return self._summarize_local(text, max_length, min_length)
            else:
                return self._summarize_api(text, max_length, min_length)
        except Exception as e:
            logger.error(f"Error in summarization: {str(e)}")
            # Fall back to local if API fails
            if not self.use_local:
                logger.info("Falling back to local model")
                return self._summarize_local(text, max_length, min_length)
            raise e

class OCRService:
    """OCR service using EasyOCR."""
    
    def __init__(self):
        self.model_config = settings.AI_MODELS['ocr']
        self.reader = None
        
    def _load_model(self):
        """Load the OCR model."""
        if self.reader is None:
            try:
                import easyocr
                logger.info("Loading EasyOCR model")
                self.reader = easyocr.Reader(['en'])  # Initialize for English
            except ImportError:
                logger.error("EasyOCR not installed")
                raise ImportError("EasyOCR is required for OCR functionality")
    
    def extract_text(self, image_path):
        """Extract text from an image."""
        self._load_model()
        result = self.reader.readtext(image_path)
        # Combine all detected text
        return " ".join([text[1] for text in result])

class SpeechToTextService:
    """Speech-to-text service using Whisper or Wav2Vec2."""
    
    def __init__(self):
        self.model_config = settings.AI_MODELS['speech_to_text']
        self.model_id = self.model_config['model_id']
        self.use_local = self.model_config['use_local']
        self.model = None
        
    def _load_local_model(self):
        """Load the speech-to-text model locally."""
        if self.model is None:
            logger.info(f"Loading local speech-to-text model: {self.model_id}")
            if 'whisper' in self.model_id.lower():
                import whisper
                self.model = whisper.load_model("small")  # or "tiny", "base", "medium", "large"
            else:
                # Wav2Vec2 implementation
                self.model = pipeline("automatic-speech-recognition", model=self.model_id)
    
    def _transcribe_api(self, audio_path):
        """Use Hugging Face API for speech-to-text."""
        API_URL = f"https://api-inference.huggingface.co/models/{self.model_id}"
        headers = get_huggingface_api_headers()
        
        with open(audio_path, "rb") as f:
            data = f.read()
        
        response = requests.post(API_URL, headers=headers, data=data)
        response.raise_for_status()
        return response.json()["text"]
    
    def _transcribe_local_whisper(self, audio_path):
        """Use local Whisper model for transcription."""
        self._load_local_model()
        result = self.model.transcribe(audio_path)
        return result["text"]
    
    def _transcribe_local_wav2vec(self, audio_path):
        """Use local Wav2Vec model for transcription."""
        self._load_local_model()
        return self.model(audio_path)["text"]
    
    def transcribe(self, audio_path):
        """Transcribe the given audio file."""
        try:
            if self.use_local:
                if 'whisper' in self.model_id.lower():
                    return self._transcribe_local_whisper(audio_path)
                else:
                    return self._transcribe_local_wav2vec(audio_path)
            else:
                return self._transcribe_api(audio_path)
        except Exception as e:
            logger.error(f"Error in transcription: {str(e)}")
            # Fall back to local if API fails
            if not self.use_local:
                logger.info("Falling back to local model")
                if 'whisper' in self.model_id.lower():
                    return self._transcribe_local_whisper(audio_path)
                else:
                    return self._transcribe_local_wav2vec(audio_path)
            raise e

# Add implementations for other services:
# - QuestionAnsweringService (Mistral or DeepSeek)
# - TextToSpeechService (Coqui TTS)
# - TranslationService (M2M-100) 