import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv('SECRET_KEY', 'django-insecure-studybot-secret-key-replace-in-production')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.getenv('DEBUG', 'True') == 'True'

ALLOWED_HOSTS = os.getenv('ALLOWED_HOSTS', 'localhost,127.0.0.1').split(',')

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third-party apps
    'rest_framework',
    'corsheaders',
    
    # Local apps
    'api',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',  # CORS middleware
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'backend.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'backend.wsgi.application'

# Database
# https://docs.djangoproject.com/en/5.1/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# We'll replace this with PostgreSQL in production
# DATABASES = {
#     'default': {
#         'ENGINE': 'django.db.backends.postgresql',
#         'NAME': 'studybot_db',
#         'USER': 'postgres',
#         'PASSWORD': 'postgres',
#         'HOST': 'localhost',
#         'PORT': '5432',
#     }
# }

# Password validation
# https://docs.djangoproject.com/en/5.1/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

# Internationalization
# https://docs.djangoproject.com/en/5.1/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'UTC'

USE_I18N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.1/howto/static-files/

STATIC_URL = 'static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

# Default primary key field type
# https://docs.djangoproject.com/en/5.1/ref/settings/#default-auto-field

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# REST Framework settings
REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': [
        'rest_framework.authentication.TokenAuthentication',
        'rest_framework.authentication.SessionAuthentication',
    ],
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
}

# CORS settings
CORS_ALLOW_ALL_ORIGINS = False  # More secure
CORS_ALLOWED_ORIGINS = os.getenv('CORS_ALLOWED_ORIGINS', 'http://localhost:3000').split(',')
CORS_ALLOW_CREDENTIALS = True

# Supabase Configuration 
SUPABASE_URL = os.getenv('SUPABASE_URL', 'https://zprjxdxttilglvlqpoct.supabase.co')
SUPABASE_KEY = os.getenv('SUPABASE_KEY', '')

# Hugging Face Models Configuration
HUGGINGFACE_API_TOKEN = os.getenv('HUGGINGFACE_API_TOKEN', '')
AI_MODELS = {
    'text_summarization': {
        'model_id': os.getenv('SUMMARIZATION_MODEL_ID', 'facebook/bart-large-cnn'),  # Updated to BART
        'use_local': os.getenv('USE_LOCAL_SUMMARIZATION', 'False') == 'True',
        'alternatives': ['t5-base', 'facebook/bart-large-cnn'],
    },
    'speech_to_text': {
        'model_id': os.getenv('SPEECH_TO_TEXT_MODEL_ID', 'openai/whisper-small'),  # Updated to Whisper
        'use_local': os.getenv('USE_LOCAL_SPEECH_TO_TEXT', 'False') == 'True',
        'alternatives': ['openai/whisper-small', 'facebook/wav2vec2-base-960h'],
    },
    'translation': {
        'model_id': os.getenv('TRANSLATION_MODEL_ID', 'facebook/m2m100_418M'),  # Updated to M2M-100
        'use_local': os.getenv('USE_LOCAL_TRANSLATION', 'False') == 'True',
    },
    'question_answering': {
        'model_id': os.getenv('QA_MODEL_ID', 'mistralai/Mistral-7B-Instruct-v0.2'),  # Updated to Mistral 7B
        'use_local': os.getenv('USE_LOCAL_QA', 'False') == 'True',
        'alternatives': ['mistralai/Mistral-7B-Instruct-v0.2', 'deepseek-ai/deepseek-chat-1.3b'],
    },
    'ocr': {
        'type': os.getenv('OCR_TYPE', 'easyocr'),  # EasyOCR instead of Google Vision
        'use_local': True,  # EasyOCR runs locally
    },
    'text_to_speech': {
        'model_id': os.getenv('TTS_MODEL_ID', 'coqui/XTTS-v2'),  # Added Coqui TTS
        'use_local': os.getenv('USE_LOCAL_TTS', 'False') == 'True',
    },
} 