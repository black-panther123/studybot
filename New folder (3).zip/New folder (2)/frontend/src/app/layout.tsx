import { Inter } from 'next/font/google';
import '../styles/globals.css';
import { ReactNode } from 'react';

const inter = Inter({ subsets: ['latin'] });

export const metadata = {
  title: 'Study Bot - AI Learning Assistant',
  description: 'AI-powered learning assistant for students and educators',
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <main className="min-h-screen bg-gradient-to-b from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-indigo-950">
          {children}
        </main>
      </body>
    </html>
  );
} 