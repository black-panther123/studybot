'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function Dashboard() {
  const [userName, setUserName] = useState('');
  const [userRole, setUserRole] = useState('');

  useEffect(() => {
    // Get user data from localStorage
    const user = localStorage.getItem('user');
    if (user) {
      const userData = JSON.parse(user);
      setUserName(userData.fullName || userData.email || 'User');
      setUserRole(userData.role || 'student');
    }
  }, []);

  // Feature cards
  const features = [
    {
      title: 'Text Summarization',
      description: 'Condense long texts into concise summaries',
      icon: '📝',
      link: '/dashboard/summarize',
      color: 'bg-blue-500',
    },
    {
      title: 'Flashcard Generation',
      description: 'Create study flashcards from your notes',
      icon: '🗂️',
      link: '/dashboard/flashcards',
      color: 'bg-green-500',
    },
    {
      title: 'OCR Text Extraction',
      description: 'Extract text from images and documents',
      icon: '📷',
      link: '/dashboard/ocr',
      color: 'bg-purple-500',
    },
    {
      title: 'AI Chatbot',
      description: 'Get instant answers to your questions',
      icon: '🤖',
      link: '/dashboard/chatbot',
      color: 'bg-orange-500',
    }
  ];

  // Admin-only features
  const adminFeatures = [
    {
      title: 'User Management',
      description: 'Manage student accounts and permissions',
      icon: '👥',
      link: '/dashboard/users',
      color: 'bg-pink-500',
    },
    {
      title: 'Usage Analytics',
      description: 'View platform usage statistics',
      icon: '📈',
      link: '/dashboard/analytics',
      color: 'bg-indigo-500',
    }
  ];

  return (
    <div className="animate-fade-in">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Welcome back, {userName}!
        </h1>
        <p className="text-gray-600 dark:text-gray-300 mt-1">
          Here's an overview of your Study Bot tools and recent activity.
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Recent Summaries</h3>
          <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">3</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Flashcard Sets</h3>
          <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">8</p>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6">
          <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Chat Sessions</h3>
          <p className="mt-2 text-3xl font-semibold text-gray-900 dark:text-white">12</p>
        </div>
      </div>

      {/* Features Grid */}
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
        Learning Tools
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {features.map((feature, index) => (
          <Link
            key={index}
            href={feature.link}
            className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow"
          >
            <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center text-white text-2xl mb-4`}>
              {feature.icon}
            </div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              {feature.title}
            </h3>
            <p className="text-gray-600 dark:text-gray-300">
              {feature.description}
            </p>
          </Link>
        ))}
      </div>

      {/* Admin Features - Only show if user is admin */}
      {userRole === 'admin' && (
        <>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
            Administrative Tools
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {adminFeatures.map((feature, index) => (
              <Link
                key={index}
                href={feature.link}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow"
              >
                <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center text-white text-2xl mb-4`}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300">
                  {feature.description}
                </p>
              </Link>
            ))}
          </div>
        </>
      )}

      {/* Recent Activity */}
      <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
        Recent Activity
      </h2>
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md divide-y divide-gray-200 dark:divide-gray-700">
        {[
          { action: 'Created summary', document: 'Introduction to Neural Networks', time: '2 hours ago' },
          { action: 'Generated flashcards', document: 'Spanish Vocabulary Chapter 5', time: '1 day ago' },
          { action: 'Used OCR', document: 'History Textbook Page 42', time: '3 days ago' },
        ].map((activity, index) => (
          <div key={index} className="p-4 flex items-center">
            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center flex-shrink-0">
              <span className="text-blue-600 dark:text-blue-400">
                {index + 1}
              </span>
            </div>
            <div className="ml-4 flex-1">
              <p className="text-sm font-medium text-gray-900 dark:text-white">
                {activity.action}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {activity.document}
              </p>
            </div>
            <div className="text-sm text-gray-500 dark:text-gray-400">
              {activity.time}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
} 