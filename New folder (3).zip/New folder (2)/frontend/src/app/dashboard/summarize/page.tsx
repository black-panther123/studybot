'use client';

import { useState } from 'react';

export default function Summarize() {
  const [text, setText] = useState('');
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!text.trim()) {
      setError('Please enter some text to summarize');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // In a real implementation, we would call the Django API
      // For demo purposes, we'll create a mock summary
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate API call
      
      setSummary(`This is a summary of the provided text: ${text.substring(0, 100)}...

The text discusses key concepts and provides detailed explanations of the main ideas. The summary highlights the most important points while maintaining the core meaning of the original content.`);
    } catch (err) {
      setError('Failed to generate summary. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Text Summarization
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          Paste your text below to generate a concise summary using our AI model.
        </p>
      </div>

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4 text-sm">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="text" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Your Text
              </label>
              <textarea
                id="text"
                rows={12}
                className="input-field font-mono text-sm"
                placeholder="Paste your text here (minimum 100 characters for best results)"
                value={text}
                onChange={(e) => setText(e.target.value)}
              />
            </div>
            <button
              type="submit"
              className="btn-primary w-full py-2.5"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Summarizing...
                </span>
              ) : "Generate Summary"}
            </button>
          </form>

          <div className="mt-6">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">Settings</h3>
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 space-y-4">
              <div>
                <label htmlFor="length" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Summary Length
                </label>
                <select
                  id="length"
                  className="input-field"
                  defaultValue="medium"
                >
                  <option value="short">Short (1-2 sentences)</option>
                  <option value="medium">Medium (3-5 sentences)</option>
                  <option value="long">Long (6-8 sentences)</option>
                </select>
              </div>
              <div>
                <label htmlFor="style" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Style
                </label>
                <select
                  id="style"
                  className="input-field"
                  defaultValue="standard"
                >
                  <option value="standard">Standard</option>
                  <option value="bullet">Bullet Points</option>
                  <option value="academic">Academic</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            Summary
          </h3>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-5 min-h-[300px]">
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <p className="text-gray-500 dark:text-gray-400">Generating summary...</p>
              </div>
            ) : summary ? (
              <div className="prose dark:prose-invert max-w-none">
                <p>{summary}</p>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-center">
                <p className="text-gray-500 dark:text-gray-400 mb-2">Your summary will appear here</p>
                <p className="text-gray-400 dark:text-gray-500 text-sm">
                  Try pasting a paragraph or article from your study materials
                </p>
              </div>
            )}
          </div>

          {summary && (
            <div className="mt-4 flex flex-wrap gap-2">
              <button className="btn-secondary text-sm py-1.5 px-3 flex items-center">
                <span className="mr-1">📋</span> Copy to Clipboard
              </button>
              <button className="btn-secondary text-sm py-1.5 px-3 flex items-center">
                <span className="mr-1">💾</span> Save Summary
              </button>
              <button className="btn-secondary text-sm py-1.5 px-3 flex items-center">
                <span className="mr-1">🗂️</span> Create Flashcards
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
} 